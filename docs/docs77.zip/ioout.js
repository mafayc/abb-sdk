﻿function IOout(data)
{
			var rwServiceResource = new XMLHttpRequest();
			rwServiceResource.open("POST", "/rw/iosystem/signals/DeviceNet/d652/DOxp?action=set", true, "Default User", "robotics");
			rwServiceResource.timeout = 10000;
			rwServiceResource.setRequestHeader('content-type','application/x-www-form-urlencoded');
	rwServiceResource.send(data);
		}